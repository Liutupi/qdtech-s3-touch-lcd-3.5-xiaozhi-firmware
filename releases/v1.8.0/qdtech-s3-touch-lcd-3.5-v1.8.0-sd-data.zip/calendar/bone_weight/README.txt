QDTech 日历称骨 SD 卡数据
================================

安装：
1. 把本文件夹外层的 calendar 目录完整复制到 SD 卡根目录。
2. 最终路径应为 /calendar/bone_weight/。
3. 文件必须保持原名，不要用文字处理软件另存 songs.tsv。

内容：
- calendar.bin：1901-01-01 至 2100-12-31 的公历到农历固定记录，共 73049 天。
- weights.bin：六十甲子、农历月、农历日和十二时辰骨重表。
- songs.tsv：2.1 两至 7.2 两的 52 条称骨歌诀，UTF-8（无 BOM）。
- interpretations.tsv：与 52 条歌诀对应的现代白话解读，UTF-8（无 BOM）。
- details.tsv：按骨重区间整理的性格、事业财务、人际情感和生活建议分章节解读。
- manifest.json：数据格式、范围和来源信息。
- licenses/：上游 MIT 许可证。

规则：
- 输入为公历出生年、月、日和 0-23 时。
- 23 时按次日子时换日；00 时仍为当日子时。
- 闰月初一至十五按本月，十六日起按下一个月的月重计算。
- 结果只作传统民俗文化娱乐参考，不构成现实决策建议。

数据来源：
- 农历日历：CrazyOrr/lunar-calendar（MIT），数据说明基于香港天文台公开资料。
  https://github.com/CrazyOrr/lunar-calendar
- 称骨表和歌诀：Ficere/tianji references/weight-tables.md（MIT）。
  https://github.com/Ficere/tianji

编码：
- README、manifest、songs.tsv、interpretations.tsv 和 details.tsv 均为 UTF-8。
- songs.tsv 每行格式为：总钱数<TAB>歌诀。
- interpretations.tsv 每行格式为：总钱数<TAB>白话解读。
- details.tsv 每行格式为：最小钱数<TAB>最大钱数<TAB>页码<TAB>章节解读。
- 阅读页共六页：歌诀、总体释义、性格与处事、事业与财务、人际与情感、生活建议。
- 固件每次翻页只读取当前页，不会一次把全部长文载入内存。
- 白话解读采用非断言式表达，不应作为健康、财务或人生决策依据。
- 白话解读由本项目根据歌诀整理，不属于传统歌诀原文。
